echo "Details in Descending order of Booking ID"

awk -F'|' '{print $1,$4,$3}' parcel.txt | sort -t' ' -k1,1nr
