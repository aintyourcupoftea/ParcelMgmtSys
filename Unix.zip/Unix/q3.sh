echo "Enter start date in YYYYMMDD format:"
read start
echo "Enter end date in YYYYMMDD format:"
read end
awk -v start="$start" -v end="$end" -f Bookings_date.awk booking.txt
