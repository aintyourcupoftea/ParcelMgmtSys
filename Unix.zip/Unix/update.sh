echo "enter customer id:"
read id
echo "enter new mail id:"
read new_mail

FILE="customer.txt"

awk -F'|' -v id="$id" -v new="$new_mail" 'BEGIN{OFS=FS}
{if ($1 == id) $4 = new}' "$FILE" > temp.txt && mv temp.txt "$FILE"
echo " updated successfully!"
