echo "enter pattern:"
read patt
FILE="customer.txt"
awk -F'|' '{print $2}' "$FILE" | grep -i "^$patt"
