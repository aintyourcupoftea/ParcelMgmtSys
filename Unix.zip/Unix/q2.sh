echo "enter booking id:"
read id

awk -v id="$id" -f Booking.awk booking.txt
