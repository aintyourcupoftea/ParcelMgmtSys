read -p "Enter ID:" id
read -p "Enter mail:" newm
awk -F'|' -v id="$id" -v new="$newm" 'BEGIN {OFS="|"}
$1 == id {$4 = new} {print $0}' customer.txt > temp.txt && mv temp.txt customer.txt
