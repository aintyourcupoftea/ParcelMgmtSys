package com.eazydeals.helper;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class ConnectionProvider{
	
	private static final long serialVersionUID = 1L;
	private static Connection connection;

	public static Connection getConnection() {

		try {
			if (connection == null) {
				
//				Class.forName("org.apache.derby.jdbc.EmbeddedDriver");
//				connection = DriverManager.getConnection("jdbc:derby:D:\\Users\\2792581\\dd;create=true");
				Class.forName("org.apache.derby.jdbc.EmbeddedDriver");
				connection = DriverManager.getConnection("jdbc:derby:D:\\Users\\2792581\\dd;create=true");
				
				System.out.println("db connected");
			}
		} catch (Exception e) {
			System.out.println("error : "+e.getMessage());
		}
		return connection;
	}
	public static void close(){
		try{
			if(connection!= null){
				connection.close();
				connection = null;
			}
		}catch(SQLException e){
			System.out.println(e.getMessage());
		}
	}
	public static void main(String arhs){
		Connection comn = ConnectionProvider.getConnection();
	}

}
